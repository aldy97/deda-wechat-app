"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const request_1 = require("./utils/request");
const api_1 = require("./api/api");
/**
 * 连通性检查：调用 /health 确认服务端可达
 */
function checkServerHealth() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const res = yield (0, request_1.request)({
                method: "GET",
                url: "/health",
            });
            console.log("[App] server health:", res.data);
        }
        catch (error) {
            console.error("[App] server health check failed:", error);
        }
    });
}
/**
 * 小程序全局入口
 * 首屏即设备列表；token 缺失时由 ensureAuthToken 静默换取（wx.login → JWT），
 * 登录页仅作为 wx.login 失败/401 时的兜底。
 */
App({
    globalData: {
        // 全局用户信息占位，登录成功后可在各页面读取
        userInfo: null,
    },
    onLaunch() {
        console.log("[App] onLaunch");
        checkServerHealth();
        // 预热静默登录：token 缺失时后台换取，页面请求经 ensureAuthToken 自动等待
        (0, api_1.ensureAuthToken)().catch((error) => {
            console.warn("[App] silent auth warm-up failed:", error);
        });
    },
    onShow() {
        console.log("[App] onShow");
    },
    onHide() {
        console.log("[App] onHide");
    },
});
