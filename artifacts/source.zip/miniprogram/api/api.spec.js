"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const api_1 = require("./api");
const request_1 = require("../utils/request");
jest.mock("../utils/request", () => ({ request: jest.fn() }));
const mockRequest = request_1.request;
describe("learning stats daily request", () => {
    beforeEach(() => {
        jest.clearAllMocks();
        mockRequest.mockResolvedValue({ code: 0, message: "success", data: [] });
    });
    it("serializes scope=all for the parent report trend", () => __awaiter(void 0, void 0, void 0, function* () {
        yield (0, api_1.getLearningStatsDaily)("dev-local-001", 7, { scope: "all" });
        expect(mockRequest).toHaveBeenCalledWith({
            method: "GET",
            url: "/learning-stats/daily?days=7&deviceId=dev-local-001&scope=all",
        });
    }));
    it("keeps existing mode filtering unchanged when scope is omitted", () => __awaiter(void 0, void 0, void 0, function* () {
        yield (0, api_1.getLearningStatsDaily)("dev-local-001", 7, { mode: "free_chat" });
        expect(mockRequest).toHaveBeenCalledWith({
            method: "GET",
            url: "/learning-stats/daily?days=7&deviceId=dev-local-001&mode=free_chat",
        });
    }));
    it("posts feedback without accepting a client-side user id", () => __awaiter(void 0, void 0, void 0, function* () {
        yield (0, api_1.submitFeedback)({
            content: "建议增加夜间模式",
            contact: "13800138000",
        });
        expect(mockRequest).toHaveBeenCalledWith({
            method: "POST",
            url: "/feedbacks",
            data: {
                content: "建议增加夜间模式",
                contact: "13800138000",
            },
        });
    }));
    it("exchanges the one-time Wechat phone code through the backend", () => __awaiter(void 0, void 0, void 0, function* () {
        yield (0, api_1.getWechatPhoneNumber)("phone-code");
        expect(mockRequest).toHaveBeenCalledWith({
            method: "POST",
            url: "/users/wechat-phone",
            data: { code: "phone-code" },
        });
    }));
    it("puts the complete device order", () => __awaiter(void 0, void 0, void 0, function* () {
        yield (0, api_1.updateDeviceOrder)(["dev-002", "dev-001"]);
        expect(mockRequest).toHaveBeenCalledWith({
            method: "PUT",
            url: "/devices/order",
            data: { orderedDeviceIds: ["dev-002", "dev-001"] },
        });
    }));
});
