"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.request = request;
const api_config_1 = require("../config/api.config");
/** 401 全局重定向守卫：并发请求同时 401 时只 reLaunch 一次 */
let isRedirectingToLogin = false;
/**
 * 401 统一处理：清除失效 token 并回到登录页。
 * 开发/生产环境行为一致，不允许页面停留在白屏或只弹 toast。
 */
function handleUnauthorized() {
    if (isRedirectingToLogin)
        return;
    isRedirectingToLogin = true;
    wx.removeStorageSync("token");
    wx.reLaunch({
        url: "/pages/login/login",
        complete: () => {
            isRedirectingToLogin = false;
        },
    });
}
function request(options) {
    const token = wx.getStorageSync("token") || "";
    const url = `${api_config_1.API_BASE_URL}${options.url}`;
    return new Promise((resolve, reject) => {
        wx.request({
            url,
            method: options.method,
            data: options.data,
            header: {
                "Content-Type": "application/json",
                Authorization: token ? `Bearer ${token}` : "",
            },
            success: (res) => {
                const statusCode = res.statusCode || 0;
                const body = res.data;
                // 401 无论以 HTTP 状态码还是业务 code 返回，都统一走全局重登录
                if (statusCode === 401 || (body === null || body === void 0 ? void 0 : body.code) === 401) {
                    console.warn(`[request] unauthorized: ${url}`);
                    handleUnauthorized();
                    reject(new Error("登录已过期，请重新登录"));
                    return;
                }
                if (statusCode >= 200 && statusCode < 300) {
                    if (body && typeof body.code === "number" && body.code !== 0) {
                        console.warn(`[request] business error: ${url}`, body);
                        reject(new Error(body.message || "Request failed"));
                    }
                    else {
                        resolve(body);
                    }
                }
                else {
                    console.error(`[request] HTTP error: ${url}`, statusCode, body);
                    const message = (body === null || body === void 0 ? void 0 : body.message) || `HTTP ${statusCode}`;
                    reject(new Error(message));
                }
            },
            fail: (err) => {
                console.error(`[request] network error: ${url}`, err);
                reject(new Error(err.errMsg || "Network error"));
            },
        });
    });
}
