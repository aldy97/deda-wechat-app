"use strict";
/**
 * 小程序组件装配测试基座。
 *
 * 与 page-harness 类似：在 node 环境桩掉全局 Component、wx，
 * 捕获组件配置，创建可驱动实例，用于断言组件内部状态与事件触发。
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.installComponentHarness = installComponentHarness;
function installComponentHarness() {
    const wxStub = {
        navigateTo: jest.fn(),
        switchTab: jest.fn(),
        navigateBack: jest.fn(),
        setNavigationBarTitle: jest.fn(),
        showToast: jest.fn(),
    };
    globalThis.wx = wxStub;
    let captured = null;
    globalThis.Component = jest.fn((config) => {
        captured = config;
    });
    return {
        wx: wxStub,
        getComponentConfig: () => captured,
        createInstance: (props) => {
            var _a, _b, _c;
            if (!captured) {
                throw new Error("未捕获到 Component 配置,请先 require 组件模块");
            }
            const instance = Object.create(null);
            Object.assign(instance, captured);
            // 将 methods 中的方法展平到实例上，与小程序运行时行为一致
            if (captured.methods) {
                Object.assign(instance, captured.methods);
            }
            for (const key of Object.keys(instance)) {
                if (typeof instance[key] === "function") {
                    instance[key] = instance[key].bind(instance);
                }
            }
            if (captured.observers) {
                const boundObservers = {};
                for (const key of Object.keys(captured.observers)) {
                    const observer = captured.observers[key];
                    boundObservers[key] =
                        typeof observer === "function" ? observer.bind(instance) : observer;
                }
                instance.observers = boundObservers;
            }
            if (captured.lifetimes) {
                const boundLifetimes = {};
                for (const key of Object.keys(captured.lifetimes)) {
                    const lifetime = captured.lifetimes[key];
                    boundLifetimes[key] =
                        typeof lifetime === "function" ? lifetime.bind(instance) : lifetime;
                }
                instance.lifetimes = boundLifetimes;
            }
            const propertyDefaults = {};
            for (const [key, def] of Object.entries((_a = captured.properties) !== null && _a !== void 0 ? _a : {})) {
                propertyDefaults[key] = def === null || def === void 0 ? void 0 : def.value;
            }
            instance.data = JSON.parse(JSON.stringify(Object.assign(Object.assign({}, propertyDefaults), ((_b = captured.data) !== null && _b !== void 0 ? _b : {}))));
            instance.properties = Object.assign(Object.assign({}, ((_c = captured.properties) !== null && _c !== void 0 ? _c : {})), (props !== null && props !== void 0 ? props : {}));
            // 将传入的 props 值同步到 data，模拟小程序 properties 绑定行为
            for (const [key, value] of Object.entries(props !== null && props !== void 0 ? props : {})) {
                instance.data[key] = value;
            }
            instance.triggerEvent = jest.fn();
            instance.setData = jest.fn((patch, cb) => {
                var _a, _b, _c;
                for (const [key, value] of Object.entries(patch)) {
                    if (key.includes(".")) {
                        const [top, ...rest] = key.split(".");
                        const leaf = rest.pop();
                        let node = (_a = instance.data[top]) !== null && _a !== void 0 ? _a : {};
                        for (const part of rest)
                            node = (_b = node[part]) !== null && _b !== void 0 ? _b : {};
                        node[leaf] = value;
                        instance.data[top] = (_c = instance.data[top]) !== null && _c !== void 0 ? _c : node;
                    }
                    else {
                        instance.data[key] = value;
                    }
                }
                if (typeof cb === "function")
                    cb();
            });
            return instance;
        },
    };
}
