"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const api_1 = require("../../api/api");
const CARD_SLOT_RPX = 176;
Page({
    data: {
        loading: true,
        loadError: false,
        saving: false,
        draggingIndex: -1,
        children: [],
    },
    dragState: null,
    onLoad() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.loadChildren();
        });
    },
    loadChildren() {
        return __awaiter(this, void 0, void 0, function* () {
            this.setData({ loading: true, loadError: false });
            try {
                yield (0, api_1.ensureAuthToken)();
                const res = yield (0, api_1.getDeviceList)();
                const children = (res.data || [])
                    .filter((device) => Boolean(device.id))
                    .map((device) => {
                    var _a, _b;
                    return ({
                        deviceId: device.id,
                        name: ((_a = device.childProfile) === null || _a === void 0 ? void 0 : _a.name) ||
                            ((_b = device.childProfile) === null || _b === void 0 ? void 0 : _b.englishName) ||
                            device.name ||
                            "未命名孩子",
                        dragOffset: 0,
                    });
                });
                this.setData({ children });
            }
            catch (error) {
                this.setData({ children: [], loadError: true });
            }
            finally {
                this.setData({ loading: false });
            }
        });
    },
    onChildTap(event) {
        const deviceId = event.currentTarget.dataset.deviceId;
        if (!deviceId)
            return;
        wx.navigateTo({
            url: `/pages/child-info/child-info?deviceId=${encodeURIComponent(deviceId)}`,
        });
    },
    onDragStart(event) {
        if (this.data.saving || this.data.children.length < 2)
            return;
        const index = Number(event.currentTarget.dataset.index);
        const touch = event.touches[0];
        if (!touch || !Number.isInteger(index))
            return;
        const { windowWidth } = wx.getWindowInfo();
        const slotHeight = (CARD_SLOT_RPX * windowWidth) / 750;
        const originalChildren = this.data.children.map((item) => (Object.assign(Object.assign({}, item), { dragOffset: 0 })));
        this.dragState = {
            startY: touch.clientY,
            index,
            targetIndex: index,
            slotHeight,
            originalChildren,
        };
        this.setData({ draggingIndex: index, children: originalChildren });
    },
    onDragMove(event) {
        const state = this.dragState;
        const touch = event.touches[0];
        if (!state || !touch)
            return;
        const lastIndex = state.originalChildren.length - 1;
        const rawOffset = touch.clientY - state.startY;
        const offset = Math.max(-state.index * state.slotHeight, Math.min((lastIndex - state.index) * state.slotHeight, rawOffset));
        const targetIndex = Math.max(0, Math.min(lastIndex, state.index + Math.round(offset / state.slotHeight)));
        state.targetIndex = targetIndex;
        const children = state.originalChildren.map((item, itemIndex) => {
            let dragOffset = 0;
            if (itemIndex === state.index) {
                dragOffset = offset;
            }
            else if (targetIndex > state.index &&
                itemIndex > state.index &&
                itemIndex <= targetIndex) {
                dragOffset = -state.slotHeight;
            }
            else if (targetIndex < state.index &&
                itemIndex >= targetIndex &&
                itemIndex < state.index) {
                dragOffset = state.slotHeight;
            }
            return Object.assign(Object.assign({}, item), { dragOffset });
        });
        this.setData({ children });
    },
    onDragEnd() {
        return __awaiter(this, void 0, void 0, function* () {
            var _a;
            const state = this.dragState;
            if (!state)
                return;
            this.dragState = null;
            this.setData({ draggingIndex: -1 });
            const previousChildren = state.originalChildren;
            if (state.targetIndex === state.index) {
                this.setData({ children: previousChildren });
                return;
            }
            const reordered = previousChildren.slice();
            const [moved] = reordered.splice(state.index, 1);
            reordered.splice(state.targetIndex, 0, moved);
            const optimisticChildren = reordered.map((item) => (Object.assign(Object.assign({}, item), { dragOffset: 0 })));
            this.setData({ children: optimisticChildren, saving: true });
            try {
                const res = yield (0, api_1.updateDeviceOrder)(optimisticChildren.map((item) => item.deviceId));
                const savedIds = ((_a = res.data) === null || _a === void 0 ? void 0 : _a.orderedDeviceIds) || [];
                const byId = new Map(optimisticChildren.map((item) => [item.deviceId, item]));
                const serverOrdered = savedIds.reduce((items, deviceId) => {
                    const item = byId.get(deviceId);
                    if (item)
                        items.push(item);
                    return items;
                }, []);
                if (serverOrdered.length === optimisticChildren.length) {
                    this.setData({ children: serverOrdered });
                }
            }
            catch (error) {
                this.setData({ children: previousChildren });
                wx.showToast({ title: "排序保存失败", icon: "none" });
            }
            finally {
                this.setData({ saving: false });
            }
        });
    },
    onDragCancel() {
        if (!this.dragState)
            return;
        const originalChildren = this.dragState.originalChildren;
        this.dragState = null;
        this.setData({ draggingIndex: -1, children: originalChildren });
    },
    // 阻止排序手柄的 tap 冒泡成“进入孩子信息”。
    onDragHandleTap() { },
});
