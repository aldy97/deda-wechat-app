"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const page_harness_1 = require("../../tests/page-harness");
const mockApi = {
    ensureAuthToken: jest.fn(),
    getDeviceList: jest.fn(),
    updateDeviceOrder: jest.fn(),
};
jest.mock("../../api/api", () => mockApi);
describe("child list page", () => {
    const harness = (0, page_harness_1.installPageHarness)();
    let page;
    beforeAll(() => {
        require("./child-list");
    });
    beforeEach(() => {
        jest.clearAllMocks();
        page = harness.createInstance();
        harness.wx.getWindowInfo = jest.fn().mockReturnValue({ windowWidth: 375 });
        mockApi.ensureAuthToken.mockResolvedValue("token");
        mockApi.getDeviceList.mockResolvedValue({
            data: [
                { id: "dev-001", name: "DEV001", childProfile: { name: "乐乐" } },
                { id: "dev 002", name: "DEV002", childProfile: { englishName: "Bagel" } },
            ],
        });
        mockApi.updateDeviceOrder.mockResolvedValue({
            data: { orderedDeviceIds: ["dev 002", "dev-001"] },
        });
    });
    it("loads children from devices and navigates with deviceId", () => __awaiter(void 0, void 0, void 0, function* () {
        yield page.onLoad();
        expect(page.data.children).toMatchObject([
            { deviceId: "dev-001", name: "乐乐" },
            { deviceId: "dev 002", name: "Bagel" },
        ]);
        page.onChildTap({ currentTarget: { dataset: { deviceId: "dev 002" } } });
        expect(harness.wx.navigateTo).toHaveBeenCalledWith({
            url: "/pages/child-info/child-info?deviceId=dev%20002",
        });
    }));
    it("shows an error state when the device request fails", () => __awaiter(void 0, void 0, void 0, function* () {
        mockApi.getDeviceList.mockRejectedValue(new Error("offline"));
        yield page.onLoad();
        expect(page.data.loadError).toBe(true);
        expect(page.data.loading).toBe(false);
        expect(page.data.children).toEqual([]);
    }));
    it("puts the complete order after dragging the first child down", () => __awaiter(void 0, void 0, void 0, function* () {
        yield page.onLoad();
        page.onDragStart({
            currentTarget: { dataset: { index: 0 } },
            touches: [{ clientY: 100 }],
        });
        page.onDragMove({ touches: [{ clientY: 276 }] });
        yield page.onDragEnd();
        expect(mockApi.updateDeviceOrder).toHaveBeenCalledWith([
            "dev 002",
            "dev-001",
        ]);
        expect(page.data.children.map((item) => item.deviceId)).toEqual([
            "dev 002",
            "dev-001",
        ]);
        expect(page.data.saving).toBe(false);
    }));
    it("restores the previous order when saving fails", () => __awaiter(void 0, void 0, void 0, function* () {
        mockApi.updateDeviceOrder.mockRejectedValue(new Error("save failed"));
        yield page.onLoad();
        page.onDragStart({
            currentTarget: { dataset: { index: 0 } },
            touches: [{ clientY: 100 }],
        });
        page.onDragMove({ touches: [{ clientY: 276 }] });
        yield page.onDragEnd();
        expect(page.data.children.map((item) => item.deviceId)).toEqual([
            "dev-001",
            "dev 002",
        ]);
        expect(harness.wx.showToast).toHaveBeenCalledWith({
            title: "排序保存失败",
            icon: "none",
        });
    }));
});
