"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatChildGender = formatChildGender;
exports.formatChildBirthday = formatChildBirthday;
const api_1 = require("../../api/api");
function formatChildGender(gender) {
    const normalized = gender === null || gender === void 0 ? void 0 : gender.trim().toLowerCase();
    if (normalized === "male" || normalized === "m" || normalized === "男") {
        return "王子";
    }
    if (normalized === "female" ||
        normalized === "f" ||
        normalized === "女") {
        return "公主";
    }
    return "未设置";
}
function formatChildBirthday(birthday) {
    return birthday ? birthday.slice(0, 10).replace(/-/g, ".") : "未设置";
}
Page({
    data: {
        loading: true,
        loadError: false,
        deviceId: "",
        childName: "未设置",
        genderLabel: "未设置",
        birthdayLabel: "未设置",
    },
    onLoad(options) {
        return __awaiter(this, void 0, void 0, function* () {
            const deviceId = (options === null || options === void 0 ? void 0 : options.deviceId) || "";
            this.setData({ deviceId });
            if (!deviceId) {
                this.setData({ loading: false, loadError: true });
                return;
            }
            yield this.loadChildInfo();
        });
    },
    loadChildInfo() {
        return __awaiter(this, void 0, void 0, function* () {
            this.setData({ loading: true, loadError: false });
            try {
                yield (0, api_1.ensureAuthToken)();
                const res = yield (0, api_1.getChildProfile)(this.data.deviceId);
                const profile = res.data;
                this.setData({
                    childName: (profile === null || profile === void 0 ? void 0 : profile.name) || (profile === null || profile === void 0 ? void 0 : profile.englishName) || "未设置",
                    genderLabel: formatChildGender(profile === null || profile === void 0 ? void 0 : profile.gender),
                    birthdayLabel: formatChildBirthday(profile === null || profile === void 0 ? void 0 : profile.birthday),
                });
            }
            catch (error) {
                this.setData({ loadError: true });
            }
            finally {
                this.setData({ loading: false });
            }
        });
    },
});
