"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const page_harness_1 = require("../../tests/page-harness");
const mockApi = {
    ensureAuthToken: jest.fn(),
    getChildProfile: jest.fn(),
};
jest.mock("../../api/api", () => mockApi);
describe("child info page", () => {
    const harness = (0, page_harness_1.installPageHarness)();
    let page;
    let formatChildGender;
    beforeAll(() => {
        formatChildGender = require("./child-info").formatChildGender;
    });
    beforeEach(() => {
        jest.clearAllMocks();
        page = harness.createInstance();
        mockApi.ensureAuthToken.mockResolvedValue("token");
        mockApi.getChildProfile.mockResolvedValue({
            data: {
                id: "profile-id",
                name: "乐乐",
                englishName: "Bagel",
                gender: "female",
                birthday: "2020-05-20",
            },
        });
    });
    it("maps male and female to the requested labels", () => {
        expect(formatChildGender("male")).toBe("王子");
        expect(formatChildGender("男")).toBe("王子");
        expect(formatChildGender("female")).toBe("公主");
        expect(formatChildGender("女")).toBe("公主");
        expect(formatChildGender(null)).toBe("未设置");
    });
    it("uses deviceId as the child ID and formats profile data", () => __awaiter(void 0, void 0, void 0, function* () {
        yield page.onLoad({ deviceId: "dev-001" });
        expect(mockApi.getChildProfile).toHaveBeenCalledWith("dev-001");
        expect(page.data.deviceId).toBe("dev-001");
        expect(page.data.childName).toBe("乐乐");
        expect(page.data.genderLabel).toBe("公主");
        expect(page.data.birthdayLabel).toBe("2020.05.20");
        expect(page.data.loadError).toBe(false);
    }));
});
