"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const api_1 = require("../../api/api");
const date_1 = require("../../utils/date");
const learning_data_utils_1 = require("./learning-data.utils");
const MODE_LABELS = {
    free_chat: "自由对话",
    daily_adventure: "每日冒险",
    adventure: "每日冒险",
    story: "故事",
    sleep: "哄睡故事",
    sleep_story: "哄睡故事",
    bedtime: "哄睡故事",
    music: "音乐",
    textbook_learning: "英语互动",
    locked_unit: "英语互动",
    free_textbook: "英语互动",
    device_control: "设备控制",
    unknown: "其他",
};
const MODE_COLORS = [
    "var(--color-mode-1)",
    "var(--color-mode-2)",
    "var(--color-mode-3)",
    "var(--color-mode-4)",
    "var(--color-mode-5)",
    "var(--color-mode-6)",
];
/**
 * “更懂TA”家长日报页：只保留使用时长、功能使用和当日总结。
 * 不展示学习评分、主题分布、单元进度、学习动态或健康度。
 */
Page({
    data: {
        initialized: false,
        loadingDevices: true,
        loadingDaily: true,
        loadingReport: true,
        deviceError: false,
        dailyError: false,
        reportError: false,
        feedbackSubmitting: false,
        deviceDropdownVisible: false,
        devices: [],
        selectedDeviceId: "",
        selectedDeviceName: "",
        reportDate: "",
        reportDateLabel: "",
        reportGeneratedAt: "",
        trendBars: [],
        modeUsage: [],
        modeUsagePie: "",
        totalModeCount: 0,
        durationMinutes: 0,
        summary: null,
        hasSummaryContent: false,
        hasReportActivity: false,
        feedback: null,
    },
    onLoad() {
        return __awaiter(this, void 0, void 0, function* () {
            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            this.setData({
                reportDate: (0, date_1.formatDate)(yesterday, "YYYY-MM-DD"),
                reportDateLabel: `${yesterday.getMonth() + 1}月${yesterday.getDate()}日 · 昨天`,
            });
            yield this.initialize();
        });
    },
    onShow() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.data.initialized && !this.data.loadingDevices) {
                yield this.loadReportData();
            }
        });
    },
    onPullDownRefresh() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.data.deviceError) {
                yield this.initialize();
            }
            else {
                yield this.loadReportData();
            }
            wx.stopPullDownRefresh();
        });
    },
    initialize() {
        return __awaiter(this, void 0, void 0, function* () {
            this.setData({ loadingDevices: true, deviceError: false });
            try {
                yield (0, api_1.ensureAuthToken)();
                const res = yield (0, api_1.getDeviceList)();
                const devices = res.data || [];
                const selected = devices[0];
                this.setData({
                    devices,
                    selectedDeviceId: (selected === null || selected === void 0 ? void 0 : selected.id) || "",
                    selectedDeviceName: this.getDeviceName(selected),
                    initialized: true,
                });
                if (selected) {
                    yield this.loadReportData();
                }
                else {
                    this.setData({ loadingDaily: false, loadingReport: false });
                }
            }
            catch (error) {
                this.setData({
                    initialized: true,
                    deviceError: true,
                    devices: [],
                    loadingDaily: false,
                    loadingReport: false,
                });
                wx.showToast({ title: "设备加载失败", icon: "none" });
            }
            finally {
                this.setData({ loadingDevices: false });
            }
        });
    },
    getDeviceName(device) {
        var _a, _b;
        if (!device)
            return "暂无设备";
        return (((_a = device.childProfile) === null || _a === void 0 ? void 0 : _a.name) ||
            ((_b = device.childProfile) === null || _b === void 0 ? void 0 : _b.englishName) ||
            device.name);
    },
    loadReportData() {
        return __awaiter(this, void 0, void 0, function* () {
            const { selectedDeviceId } = this.data;
            if (!selectedDeviceId) {
                this.setData({ loadingDaily: false, loadingReport: false });
                return;
            }
            yield Promise.all([this.loadDailyTrend(), this.loadParentReport()]);
        });
    },
    loadDailyTrend() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.data.selectedDeviceId)
                return;
            this.setData({ loadingDaily: true, dailyError: false });
            try {
                const res = yield (0, api_1.getLearningStatsDaily)(this.data.selectedDeviceId, 7, {
                    scope: "all",
                });
                this.setData({ trendBars: this.buildTrendBars(res.data || []) });
            }
            catch (error) {
                this.setData({ trendBars: [], dailyError: true });
                wx.showToast({ title: "使用时长加载失败", icon: "none" });
            }
            finally {
                this.setData({ loadingDaily: false });
            }
        });
    },
    buildTrendBars(points) {
        const max = Math.max(0, ...points.map((point) => point.durationMinutes || 0));
        return points.map((point) => {
            const value = point.durationMinutes || 0;
            return {
                label: point.date.slice(5).replace("-", "/"),
                value,
                height: value > 0 && max > 0
                    ? Math.max(12, Math.round((value / max) * 180))
                    : 4,
            };
        });
    },
    loadParentReport() {
        return __awaiter(this, void 0, void 0, function* () {
            if (!this.data.selectedDeviceId)
                return;
            this.setData({ loadingReport: true, reportError: false });
            try {
                const res = yield (0, api_1.getParentReport)(this.data.selectedDeviceId, this.data.reportDate);
                const report = res.data;
                const summary = report.summary || null;
                const modeUsage = this.buildModeUsage(report.modeUsage || []);
                const totalModeCount = modeUsage.reduce((sum, item) => sum + item.count, 0);
                const durationMinutes = report.durationMinutes || 0;
                this.setData({
                    durationMinutes,
                    reportGeneratedAt: report.generatedAt
                        ? (0, date_1.formatDate)(report.generatedAt, "YYYY-MM-DD HH:mm")
                        : "",
                    modeUsage,
                    modeUsagePie: this.buildModeUsagePie(modeUsage),
                    totalModeCount,
                    summary,
                    hasSummaryContent: !!((summary === null || summary === void 0 ? void 0 : summary.expressionObservation) ||
                        (summary === null || summary === void 0 ? void 0 : summary.emotionObservation) ||
                        (summary === null || summary === void 0 ? void 0 : summary.thinkingObservation) ||
                        (summary === null || summary === void 0 ? void 0 : summary.suggestion)),
                    hasReportActivity: durationMinutes > 0 || totalModeCount > 0,
                    feedback: report.feedback,
                });
            }
            catch (error) {
                this.setData({
                    durationMinutes: 0,
                    reportGeneratedAt: "",
                    modeUsage: [],
                    modeUsagePie: "",
                    totalModeCount: 0,
                    summary: null,
                    hasSummaryContent: false,
                    hasReportActivity: false,
                    feedback: null,
                    reportError: true,
                });
                wx.showToast({ title: "家长报告加载失败", icon: "none" });
            }
            finally {
                this.setData({ loadingReport: false });
            }
        });
    },
    buildModeUsage(items) {
        const total = items.reduce((sum, item) => sum + item.count, 0);
        if (total <= 0)
            return [];
        const percentages = (0, learning_data_utils_1.allocateIntegerPercentages)(items.map((item) => item.count));
        return items.map((item, index) => ({
            mode: item.mode,
            label: MODE_LABELS[item.mode] || item.mode,
            count: item.count,
            percent: percentages[index],
            color: MODE_COLORS[index % MODE_COLORS.length],
        }));
    },
    buildModeUsagePie(items) {
        const total = items.reduce((sum, item) => sum + item.count, 0);
        if (total <= 0)
            return "";
        let start = 0;
        const segments = items.map((item, index) => {
            const end = index === items.length - 1
                ? 100
                : Number((start + (item.count / total) * 100).toFixed(4));
            const segment = `${item.color} ${start}% ${end}%`;
            start = end;
            return segment;
        });
        return `conic-gradient(${segments.join(", ")})`;
    },
    onDeviceSwitch() {
        if (this.data.devices.length <= 1)
            return;
        this.setData({
            deviceDropdownVisible: !this.data.deviceDropdownVisible,
        });
    },
    onCloseDeviceDropdown() {
        this.setData({ deviceDropdownVisible: false });
    },
    onSelectDeviceOption(event) {
        return __awaiter(this, void 0, void 0, function* () {
            const deviceId = String(event.currentTarget.dataset.id || "");
            this.setData({ deviceDropdownVisible: false });
            yield this.selectDevice(deviceId);
        });
    },
    selectDevice(deviceId) {
        return __awaiter(this, void 0, void 0, function* () {
            if (!deviceId || deviceId === this.data.selectedDeviceId)
                return;
            const device = this.data.devices.find((item) => item.id === deviceId);
            this.setData({
                selectedDeviceId: deviceId,
                selectedDeviceName: this.getDeviceName(device),
                trendBars: [],
                modeUsage: [],
                modeUsagePie: "",
                totalModeCount: 0,
                durationMinutes: 0,
                reportGeneratedAt: "",
                summary: null,
                hasSummaryContent: false,
                hasReportActivity: false,
                feedback: null,
                dailyError: false,
                reportError: false,
                loadingDaily: true,
                loadingReport: true,
            });
            yield this.loadReportData();
        });
    },
    onRetryDevices() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.initialize();
        });
    },
    onRetryDaily() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.loadDailyTrend();
        });
    },
    onRetryReport() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.loadParentReport();
        });
    },
    onUsageHelp() {
        const reportGeneratedAt = this.data.reportGeneratedAt;
        wx.showModal({
            title: "功能使用情况",
            content: reportGeneratedAt
                ? `统计结果取自近 7 天内的数据。\n报告生成时间：${reportGeneratedAt}`
                : "统计结果取自近 7 天内的数据。\n暂未取得本次报告的生成时间，请稍后重试。",
            showCancel: false,
            confirmText: "确定",
        });
    },
    onFeedback(event) {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.data.feedbackSubmitting ||
                this.data.feedback ||
                !this.data.selectedDeviceId ||
                !this.data.hasSummaryContent) {
                return;
            }
            const rawValue = event.currentTarget.dataset.useful;
            const useful = rawValue === true || rawValue === "true";
            this.setData({ feedbackSubmitting: true });
            try {
                const res = yield (0, api_1.submitParentReportFeedback)({
                    deviceId: this.data.selectedDeviceId,
                    reportDate: this.data.reportDate,
                    useful,
                });
                this.setData({ feedback: res.data.feedback });
                wx.showToast({ title: "感谢你的反馈", icon: "none" });
            }
            catch (error) {
                wx.showToast({ title: "反馈提交失败，请重试", icon: "none" });
            }
            finally {
                this.setData({ feedbackSubmitting: false });
            }
        });
    },
});
