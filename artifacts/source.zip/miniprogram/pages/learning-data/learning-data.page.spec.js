"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
/** “更懂TA”家长日报页：三类汇报、设备切换、异常状态与反馈。 */
const page_harness_1 = require("../../tests/page-harness");
const mockApi = {
    ensureAuthToken: jest.fn(),
    getDeviceList: jest.fn(),
    getLearningStatsDaily: jest.fn(),
    getParentReport: jest.fn(),
    submitParentReportFeedback: jest.fn(),
};
jest.mock("../../api/api", () => mockApi);
const devices = [
    { id: "d1", name: "Elly 一号", childProfile: { name: "小明" } },
    { id: "d2", name: "Elly 二号", childProfile: { name: "小红" } },
];
function parentReport(deviceId = "d1") {
    return {
        deviceId,
        reportDate: "2026-10-30",
        generatedAt: "2026-10-31T23:05:00",
        durationMinutes: 20,
        modeUsage: [
            { mode: "free_chat", count: 17 },
            { mode: "daily_adventure", count: 4 },
        ],
        summary: {
            expressionObservation: "愿意主动表达。",
            emotionObservation: "整体情绪平稳。",
            thinkingObservation: "会主动提出问题。",
            suggestion: "继续顺着兴趣聊下去。",
        },
        habits: [],
        feedback: null,
    };
}
describe("learning-data parent report page", () => {
    const harness = (0, page_harness_1.installPageHarness)();
    let page;
    beforeAll(() => {
        require("./learning-data");
    });
    beforeEach(() => {
        jest.clearAllMocks();
        page = harness.createInstance();
        mockApi.ensureAuthToken.mockResolvedValue("token");
        mockApi.getDeviceList.mockResolvedValue({ data: devices });
        mockApi.getLearningStatsDaily.mockResolvedValue({
            data: [
                { date: "2026-10-30", durationMinutes: 20, sessionCount: 4 },
                { date: "2026-10-31", durationMinutes: 0, sessionCount: 0 },
            ],
        });
        mockApi.getParentReport.mockImplementation((deviceId) => Promise.resolve({ data: parentReport(deviceId) }));
        mockApi.submitParentReportFeedback.mockResolvedValue({
            data: { reportDate: "2026-10-30", feedback: "useful" },
        });
    });
    it("loads only daily duration and parent report for the selected device", () => __awaiter(void 0, void 0, void 0, function* () {
        yield page.onLoad();
        expect(mockApi.ensureAuthToken).toHaveBeenCalled();
        expect(mockApi.getLearningStatsDaily).toHaveBeenCalledWith("d1", 7, {
            scope: "all",
        });
        expect(mockApi.getParentReport).toHaveBeenCalledWith("d1", page.data.reportDate);
        expect(page.data.trendBars).toHaveLength(2);
        expect(page.data.modeUsage[0]).toMatchObject({
            label: "自由对话",
            percent: 81,
            color: "var(--color-mode-1)",
        });
        expect(page.data.modeUsage[1]).toMatchObject({
            label: "每日冒险",
            percent: 19,
        });
        expect(page.data.modeUsagePie).toBe("conic-gradient(var(--color-mode-1) 0% 80.9524%, var(--color-mode-2) 80.9524% 100%)");
        expect(page.data.hasSummaryContent).toBe(true);
        expect(page.data.reportGeneratedAt).toBe("2026-10-31 23:05");
    }));
    it("shows the real report generation time in the usage help modal", () => __awaiter(void 0, void 0, void 0, function* () {
        yield page.onLoad();
        page.onUsageHelp();
        expect(harness.wx.showModal).toHaveBeenCalledWith({
            title: "功能使用情况",
            content: "统计结果取自近 7 天内的数据。\n报告生成时间：2026-10-31 23:05",
            showCancel: false,
            confirmText: "确定",
        });
    }));
    it("does not invent an update time when generatedAt is unavailable", () => __awaiter(void 0, void 0, void 0, function* () {
        mockApi.getParentReport.mockResolvedValue({
            data: Object.assign(Object.assign({}, parentReport("d1")), { generatedAt: null }),
        });
        yield page.onLoad();
        page.onUsageHelp();
        expect(harness.wx.showModal).toHaveBeenCalledWith({
            title: "功能使用情况",
            content: "统计结果取自近 7 天内的数据。\n暂未取得本次报告的生成时间，请稍后重试。",
            showCancel: false,
            confirmText: "确定",
        });
    }));
    it("does not request reports when no device is bound", () => __awaiter(void 0, void 0, void 0, function* () {
        mockApi.getDeviceList.mockResolvedValue({ data: [] });
        yield page.onLoad();
        expect(mockApi.getLearningStatsDaily).not.toHaveBeenCalled();
        expect(mockApi.getParentReport).not.toHaveBeenCalled();
        expect(page.data.devices).toEqual([]);
        expect(page.data.loadingReport).toBe(false);
    }));
    it("distinguishes device failure from an empty device list", () => __awaiter(void 0, void 0, void 0, function* () {
        mockApi.getDeviceList.mockRejectedValue(new Error("offline"));
        yield page.onLoad();
        expect(page.data.deviceError).toBe(true);
        expect(page.data.initialized).toBe(true);
        expect(page.data.loadingDevices).toBe(false);
    }));
    it("opens and closes the child dropdown at the switch control", () => __awaiter(void 0, void 0, void 0, function* () {
        yield page.onLoad();
        page.onDeviceSwitch();
        expect(page.data.deviceDropdownVisible).toBe(true);
        page.onCloseDeviceDropdown();
        expect(page.data.deviceDropdownVisible).toBe(false);
    }));
    it("selects a child from the dropdown and closes it before reloading", () => __awaiter(void 0, void 0, void 0, function* () {
        yield page.onLoad();
        page.onDeviceSwitch();
        jest.clearAllMocks();
        yield page.onSelectDeviceOption({
            currentTarget: { dataset: { id: "d2" } },
        });
        expect(page.data.deviceDropdownVisible).toBe(false);
        expect(page.data.selectedDeviceId).toBe("d2");
        expect(mockApi.getParentReport).toHaveBeenCalledWith("d2", page.data.reportDate);
    }));
    it("clears the previous child report and reloads after switching device", () => __awaiter(void 0, void 0, void 0, function* () {
        yield page.onLoad();
        jest.clearAllMocks();
        yield page.selectDevice("d2");
        expect(page.data.selectedDeviceName).toBe("小红");
        expect(page.data.modeUsage[0].percent).toBe(81);
        expect(mockApi.getLearningStatsDaily).toHaveBeenCalledWith("d2", 7, {
            scope: "all",
        });
        expect(mockApi.getParentReport).toHaveBeenCalledWith("d2", page.data.reportDate);
    }));
    it("marks zero-use days differently from reports still being generated", () => __awaiter(void 0, void 0, void 0, function* () {
        mockApi.getParentReport.mockResolvedValue({
            data: Object.assign(Object.assign({}, parentReport()), { durationMinutes: 0, modeUsage: [], summary: null }),
        });
        yield page.onLoad();
        expect(page.data.hasSummaryContent).toBe(false);
        expect(page.data.hasReportActivity).toBe(false);
    }));
    it("keeps usage data visible when the summary is not generated", () => __awaiter(void 0, void 0, void 0, function* () {
        mockApi.getParentReport.mockResolvedValue({
            data: Object.assign(Object.assign({}, parentReport()), { summary: null }),
        });
        yield page.onLoad();
        expect(page.data.hasReportActivity).toBe(true);
        expect(page.data.modeUsage).toHaveLength(2);
        expect(page.data.hasSummaryContent).toBe(false);
    }));
    it("accepts partial summary content", () => __awaiter(void 0, void 0, void 0, function* () {
        mockApi.getParentReport.mockResolvedValue({
            data: Object.assign(Object.assign({}, parentReport()), { summary: {
                    expressionObservation: "只保留表达观察。",
                    emotionObservation: null,
                    thinkingObservation: "",
                    suggestion: null,
                } }),
        });
        yield page.onLoad();
        expect(page.data.hasSummaryContent).toBe(true);
        expect(page.data.summary.expressionObservation).toBe("只保留表达观察。");
    }));
    it("keeps daily data when the parent report request fails", () => __awaiter(void 0, void 0, void 0, function* () {
        mockApi.getParentReport.mockRejectedValue(new Error("timeout"));
        yield page.onLoad();
        expect(page.data.dailyError).toBe(false);
        expect(page.data.trendBars).toHaveLength(2);
        expect(page.data.reportError).toBe(true);
        expect(page.data.loadingReport).toBe(false);
    }));
    it("keeps report data when the daily request fails", () => __awaiter(void 0, void 0, void 0, function* () {
        mockApi.getLearningStatsDaily.mockRejectedValue(new Error("timeout"));
        yield page.onLoad();
        expect(page.data.dailyError).toBe(true);
        expect(page.data.reportError).toBe(false);
        expect(page.data.modeUsage).toHaveLength(2);
    }));
    it("submits boolean feedback with deviceId and reportDate", () => __awaiter(void 0, void 0, void 0, function* () {
        yield page.onLoad();
        yield page.onFeedback({ currentTarget: { dataset: { useful: true } } });
        expect(mockApi.submitParentReportFeedback).toHaveBeenCalledWith({
            deviceId: "d1",
            reportDate: page.data.reportDate,
            useful: true,
        });
        expect(page.data.feedback).toBe("useful");
    }));
    it("keeps the unanswered state and report content when submission fails", () => __awaiter(void 0, void 0, void 0, function* () {
        yield page.onLoad();
        const originalSummary = page.data.summary;
        mockApi.submitParentReportFeedback.mockRejectedValue(new Error("HTTP 500"));
        yield page.onFeedback({ currentTarget: { dataset: { useful: true } } });
        expect(page.data.feedback).toBeNull();
        expect(page.data.summary).toEqual(originalSummary);
        expect(page.data.hasSummaryContent).toBe(true);
        expect(page.data.feedbackSubmitting).toBe(false);
        expect(harness.wx.showToast).toHaveBeenCalledTimes(1);
        expect(harness.wx.showToast).toHaveBeenCalledWith({
            title: "反馈提交失败，请重试",
            icon: "none",
        });
    }));
    it("does not submit again when the report already has feedback", () => __awaiter(void 0, void 0, void 0, function* () {
        mockApi.getParentReport.mockResolvedValue({
            data: Object.assign(Object.assign({}, parentReport("d1")), { feedback: "not_useful" }),
        });
        yield page.onLoad();
        yield page.onFeedback({ currentTarget: { dataset: { useful: true } } });
        expect(mockApi.submitParentReportFeedback).not.toHaveBeenCalled();
        expect(page.data.feedback).toBe("not_useful");
        expect(harness.wx.showToast).not.toHaveBeenCalled();
    }));
    it("allows retrying feedback after a failed submission", () => __awaiter(void 0, void 0, void 0, function* () {
        yield page.onLoad();
        mockApi.submitParentReportFeedback.mockRejectedValueOnce(new Error("HTTP 500"));
        yield page.onFeedback({ currentTarget: { dataset: { useful: true } } });
        yield page.onFeedback({ currentTarget: { dataset: { useful: true } } });
        expect(mockApi.submitParentReportFeedback).toHaveBeenCalledTimes(2);
        expect(page.data.feedback).toBe("useful");
        expect(page.data.feedbackSubmitting).toBe(false);
        expect(harness.wx.showToast).toHaveBeenLastCalledWith({
            title: "感谢你的反馈",
            icon: "none",
        });
    }));
    it("prevents duplicate feedback submission", () => __awaiter(void 0, void 0, void 0, function* () {
        yield page.onLoad();
        let resolveFeedback;
        mockApi.submitParentReportFeedback.mockImplementation(() => new Promise((resolve) => {
            resolveFeedback = resolve;
        }));
        const first = page.onFeedback({
            currentTarget: { dataset: { useful: "true" } },
        });
        const second = page.onFeedback({
            currentTarget: { dataset: { useful: "true" } },
        });
        expect(mockApi.submitParentReportFeedback).toHaveBeenCalledTimes(1);
        resolveFeedback({ data: { feedback: "useful" } });
        yield Promise.all([first, second]);
        expect(page.data.feedbackSubmitting).toBe(false);
    }));
});
