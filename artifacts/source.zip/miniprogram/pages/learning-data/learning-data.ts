import {
  Device,
  LearningStatsDailyPoint,
  ParentReport,
  ParentReportModeUsage,
  ParentReportSummary,
  ensureAuthToken,
  getDeviceList,
  getLearningStatsDaily,
  getParentReport,
  submitParentReportFeedback,
} from "../../api/api";
import { formatDate } from "../../utils/date";
import { allocateIntegerPercentages } from "./learning-data.utils";

interface TrendBar {
  label: string;
  value: number;
  height: number;
}

interface ModeUsageView {
  mode: string;
  label: string;
  count: number;
  percent: number;
  color: string;
}

const MODE_LABELS: Record<string, string> = {
  free_chat: "自由对话",
  daily_adventure: "每日冒险",
  adventure: "每日冒险",
  story: "故事",
  sleep: "哄睡故事",
  sleep_story: "哄睡故事",
  bedtime: "哄睡故事",
  music: "音乐",
  textbook_learning: "英语互动",
  locked_unit: "英语互动",
  free_textbook: "英语互动",
  device_control: "设备控制",
  unknown: "其他",
};

const MODE_COLORS = [
  "var(--color-mode-1)",
  "var(--color-mode-2)",
  "var(--color-mode-3)",
  "var(--color-mode-4)",
  "var(--color-mode-5)",
  "var(--color-mode-6)",
];

/**
 * “更懂TA”家长日报页：只保留使用时长、功能使用和当日总结。
 * 不展示学习评分、主题分布、单元进度、学习动态或健康度。
 */
Page({
  data: {
    initialized: false,
    loadingDevices: true,
    loadingDaily: true,
    loadingReport: true,
    deviceError: false,
    dailyError: false,
    reportError: false,
    feedbackSubmitting: false,
    deviceDropdownVisible: false,
    devices: [] as Device[],
    selectedDeviceId: "",
    selectedDeviceName: "",
    reportDate: "",
    reportDateLabel: "",
    reportGeneratedAt: "",
    trendBars: [] as TrendBar[],
    modeUsage: [] as ModeUsageView[],
    modeUsagePie: "",
    totalModeCount: 0,
    durationMinutes: 0,
    summary: null as ParentReportSummary | null,
    hasSummaryContent: false,
    hasReportActivity: false,
    feedback: null as ParentReport["feedback"],
  },

  async onLoad() {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    this.setData({
      reportDate: formatDate(yesterday, "YYYY-MM-DD"),
      reportDateLabel: `${yesterday.getMonth() + 1}月${yesterday.getDate()}日 · 昨天`,
    });
    await this.initialize();
  },

  async onShow() {
    if (this.data.initialized && !this.data.loadingDevices) {
      await this.loadReportData();
    }
  },

  async onPullDownRefresh() {
    if (this.data.deviceError) {
      await this.initialize();
    } else {
      await this.loadReportData();
    }
    wx.stopPullDownRefresh();
  },

  async initialize() {
    this.setData({ loadingDevices: true, deviceError: false });
    try {
      await ensureAuthToken();
      const res = await getDeviceList();
      const devices = res.data || [];
      const selected = devices[0];
      this.setData({
        devices,
        selectedDeviceId: selected?.id || "",
        selectedDeviceName: this.getDeviceName(selected),
        initialized: true,
      });
      if (selected) {
        await this.loadReportData();
      } else {
        this.setData({ loadingDaily: false, loadingReport: false });
      }
    } catch (error) {
      this.setData({
        initialized: true,
        deviceError: true,
        devices: [],
        loadingDaily: false,
        loadingReport: false,
      });
      wx.showToast({ title: "设备加载失败", icon: "none" });
    } finally {
      this.setData({ loadingDevices: false });
    }
  },

  getDeviceName(device?: Device): string {
    if (!device) return "暂无设备";
    return (
      device.childProfile?.name ||
      device.childProfile?.englishName ||
      device.name
    );
  },

  async loadReportData() {
    const { selectedDeviceId } = this.data;
    if (!selectedDeviceId) {
      this.setData({ loadingDaily: false, loadingReport: false });
      return;
    }
    await Promise.all([this.loadDailyTrend(), this.loadParentReport()]);
  },

  async loadDailyTrend() {
    if (!this.data.selectedDeviceId) return;
    this.setData({ loadingDaily: true, dailyError: false });
    try {
      const res = await getLearningStatsDaily(this.data.selectedDeviceId, 7, {
        scope: "all",
      });
      this.setData({ trendBars: this.buildTrendBars(res.data || []) });
    } catch (error) {
      this.setData({ trendBars: [], dailyError: true });
      wx.showToast({ title: "使用时长加载失败", icon: "none" });
    } finally {
      this.setData({ loadingDaily: false });
    }
  },

  buildTrendBars(points: LearningStatsDailyPoint[]): TrendBar[] {
    const max = Math.max(
      0,
      ...points.map((point) => point.durationMinutes || 0),
    );
    return points.map((point) => {
      const value = point.durationMinutes || 0;
      return {
        label: point.date.slice(5).replace("-", "/"),
        value,
        height:
          value > 0 && max > 0
            ? Math.max(12, Math.round((value / max) * 180))
            : 4,
      };
    });
  },

  async loadParentReport() {
    if (!this.data.selectedDeviceId) return;
    this.setData({ loadingReport: true, reportError: false });
    try {
      const res = await getParentReport(
        this.data.selectedDeviceId,
        this.data.reportDate,
      );
      const report = res.data;
      const summary = report.summary || null;
      const modeUsage = this.buildModeUsage(report.modeUsage || []);
      const totalModeCount = modeUsage.reduce(
        (sum, item) => sum + item.count,
        0,
      );
      const durationMinutes = report.durationMinutes || 0;
      this.setData({
        durationMinutes,
        reportGeneratedAt: report.generatedAt
          ? formatDate(report.generatedAt, "YYYY-MM-DD HH:mm")
          : "",
        modeUsage,
        modeUsagePie: this.buildModeUsagePie(modeUsage),
        totalModeCount,
        summary,
        hasSummaryContent: !!(
          summary?.expressionObservation ||
          summary?.emotionObservation ||
          summary?.thinkingObservation ||
          summary?.suggestion
        ),
        hasReportActivity: durationMinutes > 0 || totalModeCount > 0,
        feedback: report.feedback,
      });
    } catch (error) {
      this.setData({
        durationMinutes: 0,
        reportGeneratedAt: "",
        modeUsage: [],
        modeUsagePie: "",
        totalModeCount: 0,
        summary: null,
        hasSummaryContent: false,
        hasReportActivity: false,
        feedback: null,
        reportError: true,
      });
      wx.showToast({ title: "家长报告加载失败", icon: "none" });
    } finally {
      this.setData({ loadingReport: false });
    }
  },

  buildModeUsage(items: ParentReportModeUsage[]): ModeUsageView[] {
    const total = items.reduce((sum, item) => sum + item.count, 0);
    if (total <= 0) return [];
    const percentages = allocateIntegerPercentages(
      items.map((item) => item.count),
    );
    return items.map((item, index) => ({
      mode: item.mode,
      label: MODE_LABELS[item.mode] || item.mode,
      count: item.count,
      percent: percentages[index],
      color: MODE_COLORS[index % MODE_COLORS.length],
    }));
  },

  buildModeUsagePie(items: ModeUsageView[]): string {
    const total = items.reduce((sum, item) => sum + item.count, 0);
    if (total <= 0) return "";

    let start = 0;
    const segments = items.map((item, index) => {
      const end =
        index === items.length - 1
          ? 100
          : Number((start + (item.count / total) * 100).toFixed(4));
      const segment = `${item.color} ${start}% ${end}%`;
      start = end;
      return segment;
    });
    return `conic-gradient(${segments.join(", ")})`;
  },

  onDeviceSwitch() {
    if (this.data.devices.length <= 1) return;
    this.setData({
      deviceDropdownVisible: !this.data.deviceDropdownVisible,
    });
  },

  onCloseDeviceDropdown() {
    this.setData({ deviceDropdownVisible: false });
  },

  async onSelectDeviceOption(event: WechatMiniprogram.TouchEvent) {
    const deviceId = String(event.currentTarget.dataset.id || "");
    this.setData({ deviceDropdownVisible: false });
    await this.selectDevice(deviceId);
  },

  async selectDevice(deviceId: string) {
    if (!deviceId || deviceId === this.data.selectedDeviceId) return;
    const device = this.data.devices.find((item) => item.id === deviceId);
    this.setData({
      selectedDeviceId: deviceId,
      selectedDeviceName: this.getDeviceName(device),
      trendBars: [],
      modeUsage: [],
      modeUsagePie: "",
      totalModeCount: 0,
      durationMinutes: 0,
      reportGeneratedAt: "",
      summary: null,
      hasSummaryContent: false,
      hasReportActivity: false,
      feedback: null,
      dailyError: false,
      reportError: false,
      loadingDaily: true,
      loadingReport: true,
    });
    await this.loadReportData();
  },

  async onRetryDevices() {
    await this.initialize();
  },

  async onRetryDaily() {
    await this.loadDailyTrend();
  },

  async onRetryReport() {
    await this.loadParentReport();
  },

  onUsageHelp() {
    const reportGeneratedAt = this.data.reportGeneratedAt;
    wx.showModal({
      title: "功能使用情况",
      content: reportGeneratedAt
        ? `统计结果取自近 7 天内的数据。\n报告生成时间：${reportGeneratedAt}`
        : "统计结果取自近 7 天内的数据。\n暂未取得本次报告的生成时间，请稍后重试。",
      showCancel: false,
      confirmText: "确定",
    });
  },

  async onFeedback(event: WechatMiniprogram.TouchEvent) {
    if (
      this.data.feedbackSubmitting ||
      this.data.feedback ||
      !this.data.selectedDeviceId ||
      !this.data.hasSummaryContent
    ) {
      return;
    }
    const rawValue = event.currentTarget.dataset.useful;
    const useful = rawValue === true || rawValue === "true";
    this.setData({ feedbackSubmitting: true });
    try {
      const res = await submitParentReportFeedback({
        deviceId: this.data.selectedDeviceId,
        reportDate: this.data.reportDate,
        useful,
      });
      this.setData({ feedback: res.data.feedback });
      wx.showToast({ title: "感谢你的反馈", icon: "none" });
    } catch (error) {
      wx.showToast({ title: "反馈提交失败，请重试", icon: "none" });
    } finally {
      this.setData({ feedbackSubmitting: false });
    }
  },
});
