"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.allocateIntegerPercentages = allocateIntegerPercentages;
exports.groupUnitProgressByTextbook = groupUnitProgressByTextbook;
exports.formatTopicDisplayName = formatTopicDisplayName;
exports.getRangeDays = getRangeDays;
exports.getCalendarRangeDays = getCalendarRangeDays;
exports.formatTopicScore = formatTopicScore;
exports.aggregateDailyToWeekly = aggregateDailyToWeekly;
exports.scaleBarHeights = scaleBarHeights;
exports.buildContextOptions = buildContextOptions;
exports.aggregateMultiDeviceTrend = aggregateMultiDeviceTrend;
exports.groupTimelineByDayAndDevice = groupTimelineByDayAndDevice;
/**
 * 使用最大余数法分配整数百分比：先取整数下限，再按小数余数从大到小
 * 补齐剩余百分点。余数相同时按原始顺序分配，确保结果稳定且合计为 100。
 */
function allocateIntegerPercentages(counts) {
    const total = counts.reduce((sum, count) => sum + count, 0);
    if (total <= 0)
        return counts.map(() => 0);
    const allocations = counts.map((count, index) => {
        const exactPercent = (count / total) * 100;
        const percent = Math.floor(exactPercent);
        return {
            index,
            percent,
            remainder: exactPercent - percent,
        };
    });
    const remaining = 100 - allocations.reduce((sum, item) => sum + item.percent, 0);
    const byRemainder = [...allocations].sort((a, b) => b.remainder - a.remainder || a.index - b.index);
    for (let index = 0; index < remaining; index += 1) {
        byRemainder[index].percent += 1;
    }
    return allocations.map((item) => item.percent);
}
function groupUnitProgressByTextbook(items) {
    const map = new Map();
    for (const item of items) {
        const existing = map.get(item.textbookId);
        if (existing) {
            existing.units.push(item);
        }
        else {
            map.set(item.textbookId, {
                textbookId: item.textbookId,
                textbookName: item.textbookName,
                units: [item],
            });
        }
    }
    return Array.from(map.values());
}
function formatTopicDisplayName(topic) {
    const main = topic.conversationModeName || topic.textbookName || topic.mode;
    return topic.unitName ? `${main} · ${topic.unitName}` : main;
}
function getRangeDays(range) {
    const map = {
        today: 1,
        week: 7,
        month: 30,
    };
    return map[range];
}
/**
 * 自然历口径的天数（用于 daily?days=N）：
 * today=1；week=今日是本周第几天（周一=1 … 周日=7）；month=今日是本月几号。
 * now 可注入以便测试。
 */
function getCalendarRangeDays(range, now = new Date()) {
    if (range === "today")
        return 1;
    if (range === "week") {
        // getDay(): 周日=0,周一=1…周六=6 → 周一为第 1 天
        return ((now.getDay() + 6) % 7) + 1;
    }
    return now.getDate();
}
function formatTopicScore(score) {
    return score == null ? "--" : `${score}分`;
}
/**
 * 把日粒度趋势（约 30 天,最早在前）聚合为 7 天一个的周桶。
 * 用于「本月」视图,避免 30 根柱与标签溢出。
 */
function aggregateDailyToWeekly(points) {
    const buckets = [];
    for (let i = 0; i < points.length; i += 7) {
        const chunk = points.slice(i, i + 7);
        const first = chunk[0].date;
        const last = chunk[chunk.length - 1].date;
        buckets.push({
            label: first === last ? first : `${first}-${last}`,
            durationMinutes: chunk.reduce((sum, p) => sum + p.durationMinutes, 0),
            sessionCount: chunk.reduce((sum, p) => sum + p.sessionCount, 0),
        });
    }
    return buckets;
}
/**
 * 把数值序列按当前最大值（或参考上限）相对缩放为柱高（rpx）。
 * 零值给地板高度 4rpx,非零最小 8rpx 保证可见。
 */
function scaleBarHeights(values, maxHeightRpx, referenceMax) {
    if (values.length === 0)
        return [];
    const dataMax = Math.max(...values, 0);
    // 数据超过参考上限时按数据最大值缩放,否则用参考上限
    const divisor = dataMax > referenceMax ? dataMax : referenceMax;
    return values.map((v) => {
        if (v <= 0)
            return 4;
        const h = Math.round((Math.min(v, divisor) / divisor) * maxHeightRpx);
        return Math.max(h, 8);
    });
}
/**
 * 组装智能分析页的语境选择器选项。
 * 首项为「默认（当前配置）」;其后为全部练过的语境（topics 已是全量）。
 * 查看任何语境都是只读操作,不修改设备配置。
 */
function buildContextOptions(topics) {
    var _a, _b, _c, _d;
    const active = topics.find((t) => t.isActive);
    const activeLabel = active
        ? `当前（${topicContextLabel(active)}）`
        : "当前语境";
    const options = [
        { key: "default", label: activeLabel, params: {} },
    ];
    for (const t of topics) {
        if (t.mode === "free_chat") {
            options.push({
                key: `free_chat|${t.conversationModeKey}`,
                label: `自由对话 · ${(_a = t.conversationModeName) !== null && _a !== void 0 ? _a : t.conversationModeKey}`,
                params: {
                    mode: "free_chat",
                    conversationModeKey: (_b = t.conversationModeKey) !== null && _b !== void 0 ? _b : undefined,
                },
            });
        }
        else {
            options.push({
                key: `${t.textbookId}|${t.unitId}`,
                label: topicContextLabel(t),
                params: {
                    textbookId: (_c = t.textbookId) !== null && _c !== void 0 ? _c : undefined,
                    unitId: (_d = t.unitId) !== null && _d !== void 0 ? _d : undefined,
                },
            });
        }
    }
    return options;
}
function topicContextLabel(t) {
    var _a, _b, _c, _d;
    const textbook = (_b = (_a = t.textbookName) !== null && _a !== void 0 ? _a : t.textbookId) !== null && _b !== void 0 ? _b : "";
    const unit = (_d = (_c = t.unitName) !== null && _c !== void 0 ? _c : t.unitId) !== null && _d !== void 0 ? _d : "";
    return [textbook, unit].filter(Boolean).join(" · ");
}
const TREND_COLORS = [
    "var(--color-trend-1)",
    "var(--color-trend-2)",
    "var(--color-trend-3)",
    "var(--color-trend-4)",
    "var(--color-trend-5)",
    "var(--color-trend-6)",
];
function sortDateLabels(a, b) {
    const [aMonth, aDay] = a.split("/").map(Number);
    const [bMonth, bDay] = b.split("/").map(Number);
    if (aMonth !== bMonth)
        return aMonth - bMonth;
    return aDay - bDay;
}
/**
 * 把多个设备的日粒度趋势合并为多系列趋势数据。
 * 所有设备共享同一组 labels（取并集，按时间正序）。
 * 缺失的日期补 0，保证各 series.values 长度一致。
 */
function aggregateMultiDeviceTrend(deviceTrends, range) {
    if (deviceTrends.length === 0) {
        return { labels: [], series: [], maxValue: 0 };
    }
    // 收集所有日期并按自然历排序（M/D 格式）
    const dateSet = new Set();
    for (const dt of deviceTrends) {
        for (const p of dt.points) {
            dateSet.add(p.date);
        }
    }
    const labels = Array.from(dateSet).sort(sortDateLabels);
    // 月视图：把日粒度聚合为周桶
    if (range === "month" && labels.length > 7) {
        return aggregateMultiDeviceTrendToWeekly(deviceTrends);
    }
    const referenceMax = range === "today" ? 60 : range === "week" ? 120 : 300;
    const series = deviceTrends.map((dt, index) => {
        const valueMap = new Map(dt.points.map((p) => [p.date, p.durationMinutes]));
        const values = labels.map((label) => valueMap.get(label) || 0);
        const dataMax = Math.max(...values, 0);
        const divisor = dataMax > referenceMax ? dataMax : referenceMax;
        const heights = values.map((v) => {
            if (v <= 0)
                return 4;
            const h = Math.round((Math.min(v, divisor) / divisor) * 160);
            return Math.max(h, 8);
        });
        return {
            deviceId: dt.deviceId,
            deviceName: dt.deviceName,
            color: TREND_COLORS[index % TREND_COLORS.length],
            values,
            heights,
        };
    });
    const allValues = series.reduce((sum, s) => sum.concat(s.values), []);
    const maxValue = Math.max(...allValues, referenceMax);
    return { labels, series, maxValue };
}
function aggregateMultiDeviceTrendToWeekly(deviceTrends) {
    // 先按日合并，再统一分桶
    const dateSet = new Set();
    for (const dt of deviceTrends) {
        for (const p of dt.points)
            dateSet.add(p.date);
    }
    const sortedDates = Array.from(dateSet).sort(sortDateLabels);
    if (sortedDates.length === 0) {
        return { labels: [], series: [], maxValue: 0 };
    }
    const weeklyLabels = [];
    for (let i = 0; i < sortedDates.length; i += 7) {
        const chunk = sortedDates.slice(i, i + 7);
        const first = chunk[0];
        const last = chunk[chunk.length - 1];
        weeklyLabels.push(first === last ? first : `${first}-${last}`);
    }
    const referenceMax = 300;
    const series = deviceTrends.map((dt, index) => {
        const valueMap = new Map(dt.points.map((p) => [p.date, p.durationMinutes]));
        const values = [];
        for (let i = 0; i < sortedDates.length; i += 7) {
            const chunk = sortedDates.slice(i, i + 7);
            values.push(chunk.reduce((sum, date) => sum + (valueMap.get(date) || 0), 0));
        }
        const dataMax = Math.max(...values, 0);
        const divisor = dataMax > referenceMax ? dataMax : referenceMax;
        const heights = values.map((v) => {
            if (v <= 0)
                return 4;
            const h = Math.round((Math.min(v, divisor) / divisor) * 160);
            return Math.max(h, 8);
        });
        return {
            deviceId: dt.deviceId,
            deviceName: dt.deviceName,
            color: TREND_COLORS[index % TREND_COLORS.length],
            values,
            heights,
        };
    });
    const allValues = series.reduce((sum, s) => sum.concat(s.values), []);
    const maxValue = Math.max(...allValues, referenceMax);
    return { labels: weeklyLabels, series, maxValue };
}
/**
 * 把扁平时间线按日期 + 设备分组。
 * 同一设备同一天的事件聚合为一个可折叠的卡片。
 */
function groupTimelineByDayAndDevice(items) {
    if (!items || items.length === 0)
        return [];
    const dayMap = new Map();
    for (const item of items) {
        const date = item.createdAt.slice(0, 10);
        let deviceMap = dayMap.get(date);
        if (!deviceMap) {
            deviceMap = new Map();
            dayMap.set(date, deviceMap);
        }
        let group = deviceMap.get(item.deviceId);
        if (!group) {
            group = {
                deviceId: item.deviceId,
                deviceName: item.deviceName,
                totalDurationMinutes: 0,
                events: [],
                expanded: true,
            };
            deviceMap.set(item.deviceId, group);
        }
        group.events.push(item);
        // 后端目前未返回单条时长，先用 0.5 分钟/轮估算，后续可替换为真实值
        group.totalDurationMinutes += 0.5;
    }
    const sortedDays = Array.from(dayMap.keys()).sort().reverse();
    return sortedDays.map((date) => {
        const deviceMap = dayMap.get(date);
        const devices = Array.from(deviceMap.values()).map((g) => (Object.assign(Object.assign({}, g), { totalDurationMinutes: Math.round(g.totalDurationMinutes) })));
        return {
            date,
            displayDate: formatTimelineDisplayDate(date),
            devices,
        };
    });
}
function formatTimelineDisplayDate(dateStr) {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const d = new Date(dateStr);
    const fmt = (date) => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
    if (fmt(d) === fmt(today))
        return "今天";
    if (fmt(d) === fmt(yesterday))
        return "昨天";
    return `${d.getMonth() + 1}月${d.getDate()}日`;
}
