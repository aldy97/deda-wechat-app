"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const api_1 = require("../../api/api");
const page_harness_1 = require("../../tests/page-harness");
jest.mock("../../api/api", () => ({
    ensureAuthToken: jest.fn(),
    getWechatPhoneNumber: jest.fn(),
    submitFeedback: jest.fn(),
}));
const mockEnsureAuthToken = api_1.ensureAuthToken;
const mockGetWechatPhoneNumber = api_1.getWechatPhoneNumber;
const mockSubmitFeedback = api_1.submitFeedback;
describe("feedback page", () => {
    const harness = (0, page_harness_1.installPageHarness)();
    beforeAll(() => {
        require("./feedback");
    });
    beforeEach(() => {
        jest.clearAllMocks();
        mockEnsureAuthToken.mockResolvedValue("token");
        mockGetWechatPhoneNumber.mockResolvedValue({
            code: 0,
            message: "success",
            data: { phone: "13800138000" },
        });
        mockSubmitFeedback.mockResolvedValue({
            code: 0,
            message: "success",
            data: { feedbackId: "fb-1", createdAt: "2026-11-01T03:00:00Z" },
        });
    });
    it("limits pasted feedback to 200 Unicode characters", () => {
        const page = harness.createInstance();
        const result = page.onContentInput({
            detail: { value: `${"好".repeat(200)}多` },
        });
        expect(result).toHaveLength(200);
        expect(page.data.contentLength).toBe(200);
        expect(page.data.canSubmit).toBe(true);
    });
    it("rejects blank content and invalid contact numbers", () => __awaiter(void 0, void 0, void 0, function* () {
        const page = harness.createInstance();
        yield page.onSubmit();
        expect(mockSubmitFeedback).not.toHaveBeenCalled();
        page.onContentInput({ detail: { value: "希望增加夜间模式" } });
        page.onContactInput({ detail: { value: "12345" } });
        yield page.onSubmit();
        expect(mockSubmitFeedback).not.toHaveBeenCalled();
        expect(harness.wx.showToast).toHaveBeenLastCalledWith({
            title: "请输入正确的手机号",
            icon: "none",
        });
    }));
    it("prefills the phone number returned by the Wechat authorization flow", () => __awaiter(void 0, void 0, void 0, function* () {
        const page = harness.createInstance();
        yield page.onGetPhoneNumber({
            detail: { code: "phone-code", errMsg: "getPhoneNumber:ok" },
        });
        expect(mockEnsureAuthToken).toHaveBeenCalledTimes(1);
        expect(mockGetWechatPhoneNumber).toHaveBeenCalledWith("phone-code");
        expect(page.data.contact).toBe("13800138000");
        expect(page.data.phoneLoading).toBe(false);
    }));
    it("keeps manual input available when phone authorization is denied", () => __awaiter(void 0, void 0, void 0, function* () {
        const page = harness.createInstance();
        yield page.onGetPhoneNumber({
            detail: { code: "", errMsg: "getPhoneNumber:fail user deny" },
        });
        expect(mockGetWechatPhoneNumber).not.toHaveBeenCalled();
        expect(page.data.contact).toBe("");
        expect(harness.wx.showToast).not.toHaveBeenCalled();
    }));
    it("submits trimmed content with the authenticated user context", () => __awaiter(void 0, void 0, void 0, function* () {
        jest.useFakeTimers();
        const page = harness.createInstance();
        page.onContentInput({ detail: { value: "  建议增加夜间模式  " } });
        page.onContactInput({ detail: { value: "13800138000" } });
        yield page.onSubmit();
        expect(mockEnsureAuthToken).toHaveBeenCalledTimes(1);
        expect(mockSubmitFeedback).toHaveBeenCalledWith({
            content: "建议增加夜间模式",
            contact: "13800138000",
        });
        expect(harness.wx.showToast).toHaveBeenCalledWith({
            title: "提交成功",
            icon: "success",
        });
        jest.runAllTimers();
        expect(harness.wx.navigateBack).toHaveBeenCalledTimes(1);
        jest.useRealTimers();
    }));
    it("shows an inline error and preserves the form after a server failure", () => __awaiter(void 0, void 0, void 0, function* () {
        mockSubmitFeedback.mockRejectedValueOnce(new Error("HTTP 500"));
        const page = harness.createInstance();
        page.onContentInput({ detail: { value: "希望增加夜间模式" } });
        page.onContactInput({ detail: { value: "13800138000" } });
        yield page.onSubmit();
        expect(page.data.submitFailed).toBe(true);
        expect(page.data.content).toBe("希望增加夜间模式");
        expect(page.data.contact).toBe("13800138000");
        expect(page.data.canSubmit).toBe(true);
        expect(page.data.submitting).toBe(false);
        expect(harness.wx.showToast).not.toHaveBeenCalled();
    }));
    it("prevents duplicate submissions while a request is pending", () => __awaiter(void 0, void 0, void 0, function* () {
        let resolveRequest = () => undefined;
        mockSubmitFeedback.mockReturnValue(new Promise((resolve) => {
            resolveRequest = resolve;
        }));
        const page = harness.createInstance();
        page.onContentInput({ detail: { value: "第一次反馈" } });
        const firstRequest = page.onSubmit();
        yield page.onSubmit();
        expect(mockSubmitFeedback).toHaveBeenCalledTimes(1);
        resolveRequest({ code: 0, message: "success", data: {} });
        yield firstRequest;
    }));
});
