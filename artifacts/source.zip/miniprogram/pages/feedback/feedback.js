"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const api_1 = require("../../api/api");
const MAX_CONTENT_LENGTH = 200;
const MAINLAND_PHONE_PATTERN = /^1[3-9]\d{9}$/;
function countCharacters(value) {
    return Array.from(value).length;
}
function limitContent(value) {
    return Array.from(value).slice(0, MAX_CONTENT_LENGTH).join("");
}
Page({
    data: {
        content: "",
        contact: "",
        contentLength: 0,
        canSubmit: false,
        submitting: false,
        submitFailed: false,
        phoneLoading: false,
    },
    onContentInput(event) {
        const content = limitContent(String(event.detail.value || ""));
        this.setData({
            content,
            contentLength: countCharacters(content),
            canSubmit: content.trim().length > 0,
        });
        // 同步拦截粘贴等可能绕过 maxlength 的输入。
        return content;
    },
    onContactInput(event) {
        const contact = String(event.detail.value || "").trim();
        this.setData({ contact });
        return contact;
    },
    onGetPhoneNumber(event) {
        return __awaiter(this, void 0, void 0, function* () {
            const { code, errMsg } = event.detail;
            if (!code) {
                if (errMsg && !/deny|cancel/.test(errMsg)) {
                    wx.showToast({ title: "获取失败，请手动输入", icon: "none" });
                }
                return;
            }
            if (this.data.phoneLoading)
                return;
            this.setData({ phoneLoading: true });
            try {
                yield (0, api_1.ensureAuthToken)();
                const res = yield (0, api_1.getWechatPhoneNumber)(code);
                const contact = String(res.data.phone || "");
                if (!MAINLAND_PHONE_PATTERN.test(contact)) {
                    throw new Error("Invalid phone number");
                }
                this.setData({ contact, submitFailed: false });
            }
            catch (error) {
                wx.showToast({ title: "获取失败，请手动输入", icon: "none" });
            }
            finally {
                this.setData({ phoneLoading: false });
            }
        });
    },
    onSubmit() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.data.submitting)
                return;
            const content = String(this.data.content || "").trim();
            const contact = String(this.data.contact || "").trim();
            if (!content) {
                wx.showToast({ title: "请输入问题或建议", icon: "none" });
                return;
            }
            if (countCharacters(content) > MAX_CONTENT_LENGTH) {
                wx.showToast({ title: "问题或建议最多 200 字", icon: "none" });
                return;
            }
            if (contact && !MAINLAND_PHONE_PATTERN.test(contact)) {
                wx.showToast({ title: "请输入正确的手机号", icon: "none" });
                return;
            }
            this.setData({
                submitting: true,
                canSubmit: false,
                submitFailed: false,
            });
            try {
                yield (0, api_1.ensureAuthToken)();
                yield (0, api_1.submitFeedback)({
                    content,
                    contact: contact || undefined,
                });
                this.setData({
                    content: "",
                    contact: "",
                    contentLength: 0,
                });
                wx.showToast({ title: "提交成功", icon: "success" });
                setTimeout(() => {
                    wx.navigateBack();
                }, 800);
            }
            catch (error) {
                this.setData({ submitFailed: true });
            }
            finally {
                this.setData({
                    submitting: false,
                    canSubmit: String(this.data.content || "").trim().length > 0,
                });
            }
        });
    },
});
